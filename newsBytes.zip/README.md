# Task

## How To Run ?

- npm install
- npm run dev

## check postman collection

- Get URL               :- localhost:8000/short
- Get Original Website  :- localhost:8000/short/:code